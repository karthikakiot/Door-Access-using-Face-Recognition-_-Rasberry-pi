import os
import numpy as np
import cv2
from PIL import Image # For face recognition we will the the LBPH Face Recognizer
recognizer = cv2.face.createLBPHFaceRecognizer();
path="facedata"

def getImagesWithID(path):

    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]   
    faces = []
    IDs = []
    for imagePath in imagePaths:      
        faceImg = Image.open(imagePath).convert('L')
        faceNP = np.array(faceImg, 'uint8')
        ID= int(os.path.split(imagePath)[1].split(".")[1])
        print(ID)
        faces.append(faceNP)
        IDs.append(ID)
        cv2.imshow("Adding faces for traning",faceNP)
        cv2.waitKey(10)
    return faces, IDs
faces,Ids = getImagesWithID(path)
print(Ids)
recognizer.train(faces,np.array(Ids))
recognizer.save("recognizer/trainingdata.yml")
cv2.destroyAllWindows()


#hai