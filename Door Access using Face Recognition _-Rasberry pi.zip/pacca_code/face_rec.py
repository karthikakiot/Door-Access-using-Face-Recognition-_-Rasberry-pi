import numpy as np
import cv2
id_name=["","other","bharath","vinay","harsha","j.sreenath","prashanth"]
facecascade = cv2.CascadeClassifier('data/haarcascades/haarcascade_frontalface_alt.xml')
cap = cv2.VideoCapture(0)
recognizer = cv2.face.createLBPHFaceRecognizer();
recognizer.load("recognizer/trainingdata.yml")
font = cv2.FONT_HERSHEY_SIMPLEX,5,1,0,4
while True:
    ret, img =cap.read()
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces=facecascade.detectMultiScale(gray, 1.2,5)
    for(x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(225,0,0),2)
        result=cv2.face.MinDistancePredictCollector()
        recognizer.predict(gray[y:y+h,x:x+w],result)
        ID=result.getLabel()
        print(ID)
        name=id_name[ID]
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img,name,(x,y+h),font, 1, 255)
    cv2.imshow('Face',img)
    
    if cv2.waitKey(1) == ord('q'):
        break
cap.release()

cv2.destroyAllWindows()